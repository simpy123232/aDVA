export interface Comment {
    id: string;
    comment: any;
    userid:string
  }