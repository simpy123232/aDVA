export interface Answer {
    id: string;
    answer: any;
    userid:string
    questionid:string
  }