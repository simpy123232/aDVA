export class SignInModel{
    Id:number=0;
    email:string='';
    password:string='';
}
