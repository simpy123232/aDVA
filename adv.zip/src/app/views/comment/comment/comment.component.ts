import { Component, OnInit } from '@angular/core';
import { createClient } from '@supabase/supabase-js';
import { CommentService } from '../../../Services/comment.service';
import * as uuid from 'uuid';
import { Comment } from '../../../Model/comment'
import { json } from 'stream/consumers';
import { ActivatedRoute, Router } from '@angular/router';
import { Question } from 'src/app/Model/Question';
@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss']
})
export class CommentComponent {

  supabaseUrl = 'https://gluifbolndyftekyypbl.supabase.co';
  supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdsdWlmYm9sbmR5ZnRla3l5cGJsIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODAxNzUyOTQsImV4cCI6MTk5NTc1MTI5NH0.iJ9PgJDflSITsO-1nveTkdQMBb0Fc3iSnRHds2CwmI8';
  supabaseClient = createClient(this.supabaseUrl, this.supabaseKey);
  userData: any;
  answers!: { [x: string]: any; }[];
  profile!: { [x: string]: any; }[];
  questionId!: number;
  route: any;
  postAnswer: any;
  data = [''];
  question: any;
  model = {} as Question;
  postquestion: any;
  data1: any
  username: any;
  // userdetail=JSON.parse(localStorage.getItem('userinformation')!) as any;
  constructor(private _comment: CommentService, private router: Router, private routerA: ActivatedRoute) {

  }
  async getQuestions() {
    debugger;

    const userId = this.routerA.snapshot.queryParams['userid'];

    // Fetch all questions from the 'Questions' table in Supabase
    const { data, error } = await this.supabaseClient.from('Questions').select('*');
    if (data) {
      for (let item of data) {
        item['answer'] = await this.supabaseClient.from('Answers').select('*').eq('questionid', item['id']);

        item['profile'] = await this.supabaseClient.from('Profile').select('fullName').eq('userid', item['userid']);
       for(let answer of item["answer"]["data"]){
        item['answer'].data['fullName']=await this.supabaseClient.from('Profile').select('fullName').eq('userid',item[answer.userid])
       }
       
      }
    }
    if (error) {
      console.log(error);
    }
      this.postquestion = data;
    
  };

  ngOnInit() {
    debugger;
    this.getQuestions();
  }
  navigateToQuestion(questionId: string) {
    this.router.navigate(['/questionScreen', questionId]);
  }

}
