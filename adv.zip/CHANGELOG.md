### [coreui-free-angular-admin-template](https://coreui.io/angular/) changelog

---

#### `4.3.9`

- chore: dependencies update
- fix(widgets): add missing pointBackgroundColor

---

#### `4.3.0`

update to:
- `Angular 15`
- `TypeScript 4.8`
- `RxJS 7.5`

refactor: 
- refactor(AppComponent): change selector to `app-root`

---
